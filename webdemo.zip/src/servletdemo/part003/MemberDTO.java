package servletdemo.part003;

public class MemberDTO {
 private String fid;
 private String fpass;
 
public String getFid() {
	return fid;
}
public void setFid(String fid) {
	this.fid = fid;
}
public String getFpass() {
	return fpass;
}
public void setFpass(String fpass) {
	this.fpass = fpass;
}
  
 
}
